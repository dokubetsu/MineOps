'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { format } from 'date-fns'
import { Plus, X, Lock, Unlock, Camera, Image as ImageIcon } from 'lucide-react'
import { useAuth } from '@/lib/auth-context'
import { useRouter } from 'next/navigation'
import { Site, CashBook, CashEntry } from '@/lib/supabase/types'
import { cashBookRepository } from '@/lib/repositories/cash-book'
import BottomSheet from '@/components/BottomSheet'
import ConfirmDialog from '@/components/ConfirmDialog'
import toast from 'react-hot-toast'

const ENTRY_CATEGORIES_IN = ['Cash received from main office', 'Other incoming']
const ENTRY_CATEGORIES_OUT = ['Fuel/Diesel Purchase', 'Driver Wage payment', 'Supervisor payment', 'Meal & Food expense', 'Repair & Spares', 'Other outgoing']

export default function CashBookPage() {
  const { isAdmin, isSiteManager, loading: authLoading } = useAuth()
  const router = useRouter()
  const [sites, setSites] = useState<Site[]>([])
  const [selectedSite, setSelectedSite] = useState('')
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [cashBook, setCashBook] = useState<CashBook | null>(null)
  const [entries, setEntries] = useState<CashEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({
    entry_type: 'out' as 'in' | 'out',
    category: 'Fuel/Diesel Purchase',
    amount: '',
    note: '',
  })
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)
  const [submitting, setSubmitting] = useState(false)

  // Pagination states
  const [hasMore, setHasMore] = useState(false)
  const [loadingMore, setLoadingMore] = useState(false)
  const [usersMap, setUsersMap] = useState<Record<string, string>>({}) // uuid -> email

  // ConfirmDialog states
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null)
  const [confirmLock, setConfirmLock] = useState(false)

  const supabase = createClient()
  const PAGE_LIMIT = 20

  useEffect(() => {
    if (authLoading) return
    if (!isAdmin && !isSiteManager) {
      router.push('/dashboard')
      return
    }
    loadSites()
  }, [authLoading, isAdmin, isSiteManager])

  useEffect(() => {
    if (selectedSite) loadCashBook(false)
  }, [selectedSite, selectedDate])

  useEffect(() => {
    if (!selectedSite) return
    const channel = supabase
      .channel(`cash-realtime-${selectedSite}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'cash_entries',
        },
        () => {
          loadCashBook(false)
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [selectedSite, selectedDate])

  const loadSites = async () => {
    try {
      const { data } = await supabase.from('sites').select('*').eq('active', true).order('name')
      const loadedSites = data || []
      setSites(loadedSites)
      if (loadedSites.length > 0) {
        setSelectedSite(loadedSites[0].id)
      }

      // Fetch user profile map for Audit details
      const token = await supabase.auth.getSession().then(({ data }) => data.session?.access_token)
      if (token) {
        fetch('/api/admin/list-users', {
          headers: { Authorization: `Bearer ${token}` },
        })
          .then(r => r.json())
          .then(data => {
            if (data?.users) {
              const mapping: Record<string, string> = {}
              for (const u of data.users) {
                mapping[u.id] = u.email
              }
              setUsersMap(mapping)
            }
          })
          .catch(() => {})
      }
    } catch (err: any) {
      toast.error(`Error loading sites: ${err.message}`)
    }
  }

  const loadCashBook = async (loadMore = false) => {
    if (loadMore) {
      setLoadingMore(true)
    } else {
      setLoading(true)
    }
    try {
      const cb = await cashBookRepository.getOrCreate(supabase, selectedSite, selectedDate)
      setCashBook(cb)
      
      const offset = loadMore ? entries.length : 0
      const loadedEntries = await cashBookRepository.listEntries(supabase, cb.id, PAGE_LIMIT, offset)
      const cacheKeyBook = `cached_cashbook_${selectedSite}_${selectedDate}`
      const cacheKeyEntries = `cached_cashentries_${selectedSite}_${selectedDate}`
      localStorage.setItem(cacheKeyBook, JSON.stringify(cb))

      if (loadMore) {
        setEntries(prev => {
          const nextEntries = [...prev, ...loadedEntries]
          localStorage.setItem(cacheKeyEntries, JSON.stringify(nextEntries))
          return nextEntries
        })
      } else {
        setEntries(loadedEntries)
        localStorage.setItem(cacheKeyEntries, JSON.stringify(loadedEntries))
      }
      setHasMore(loadedEntries.length === PAGE_LIMIT)
    } catch (error: any) {
      const cacheKeyBook = `cached_cashbook_${selectedSite}_${selectedDate}`
      const cacheKeyEntries = `cached_cashentries_${selectedSite}_${selectedDate}`
      const cachedBook = localStorage.getItem(cacheKeyBook)
      const cachedEntries = localStorage.getItem(cacheKeyEntries)

      if (cachedBook && cachedEntries && !loadMore) {
        setCashBook(JSON.parse(cachedBook))
        setEntries(JSON.parse(cachedEntries))
        toast('Serving cached cash book (offline mode)', { icon: '📶' })
      } else {
        toast.error(`Error loading cash book: ${error.message}`)
        setCashBook(null)
        if (!loadMore) setEntries([])
      }
    } finally {
      setLoading(false)
      setLoadingMore(false)
    }
  }

  const handlePhotoSelect = (file: File) => {
    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size exceeds the 5MB limit')
      return
    }
    setPhotoFile(file)
    setPhotoPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!cashBook) return
    if (cashBook.status === 'locked') {
      toast.error('This Cash Book is locked for the day and cannot be modified.')
      return
    }

    const amt = parseFloat(form.amount)
    if (isNaN(amt) || amt <= 0) {
      toast.error('Please enter a valid amount')
      return
    }

    setSubmitting(true)
    try {
      let receiptUrl: string | null = null
      if (photoFile) {
        const ext = photoFile.name.split('.').pop() || 'jpg'
        const fileUuid = crypto.randomUUID()
        const path = `${selectedSite}/${selectedDate}/${fileUuid}.${ext}`
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('cash-receipts')
          .upload(path, photoFile, { upsert: true })

        if (uploadError) throw uploadError
        if (uploadData) receiptUrl = path
      }

      await cashBookRepository.createEntry(supabase, {
        cash_book_id: cashBook.id,
        entry_type: form.entry_type,
        category: form.category,
        amount: amt,
        note: form.note || null,
        receipt_url: receiptUrl,
      })

      toast.success('Cash entry recorded successfully')
      setShowForm(false)
      setForm({ entry_type: 'out', category: 'Fuel/Diesel Purchase', amount: '', note: '' })
      setPhotoFile(null)
      setPhotoPreview(null)
      loadCashBook()
    } catch (err: any) {
      toast.error(`Error saving cash entry: ${err.message}`)
    } finally {
      setSubmitting(false)
    }
  }

  const executeDeleteEntry = async () => {
    if (!confirmDeleteId || !cashBook) return
    if (cashBook.status === 'locked') {
      toast.error('This Cash Book is locked.')
      return
    }

    try {
      await cashBookRepository.deleteEntry(supabase, confirmDeleteId)
      toast.success('Cash entry removed')
      loadCashBook()
    } catch (error: any) {
      toast.error(`Error deleting cash entry: ${error.message}`)
    } finally {
      setConfirmDeleteId(null)
    }
  }

  const executeToggleLock = async () => {
    if (!cashBook) return
    try {
      const nextStatus = await cashBookRepository.toggleLock(supabase, cashBook.id, cashBook.status)
      toast.success(`Cash book is now ${nextStatus}`)
      loadCashBook()
    } catch (error: any) {
      toast.error(`Error toggling lock status: ${error.message}`)
    } finally {
      setConfirmLock(false)
    }
  }

  const handleEntryTypeChange = (type: 'in' | 'out') => {
    setForm(f => ({
      ...f,
      entry_type: type,
      category: type === 'in' ? ENTRY_CATEGORIES_IN[0] : ENTRY_CATEGORIES_OUT[0],
    }))
  }

  const totalIn = entries.filter(e => e.entry_type === 'in').reduce((s, e) => s + e.amount, 0)
  const totalOut = entries.filter(e => e.entry_type === 'out').reduce((s, e) => s + e.amount, 0)
  const isLocked = cashBook?.status === 'locked'

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Cash Book</h1>
          <p className="page-subtitle">Site Expense Ledger</p>
        </div>
        {cashBook && (
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <button
              className={`btn ${isLocked ? 'btn-secondary' : 'btn-primary'}`}
              onClick={() => setConfirmLock(true)}
            >
              {isLocked ? <><Unlock size={16} /> Unlock Book</> : <><Lock size={16} /> Lock Book</>}
            </button>
            <button className="btn btn-primary" onClick={() => setShowForm(true)} disabled={isLocked}>
              <Plus size={18} /> Add Entry
            </button>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="card mb-4" style={{ padding: '0.875rem 1rem' }}>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', alignItems: 'center' }}>
          {sites.length > 1 && (
            <select className="form-input form-select" style={{ flex: 1, minWidth: '140px' }}
              value={selectedSite} onChange={e => setSelectedSite(e.target.value)}>
              {sites.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          )}
          <input
            type="date"
            className="form-input"
            style={{ flex: 1, minWidth: '140px' }}
            value={selectedDate}
            onChange={e => setSelectedDate(e.target.value)}
          />
        </div>
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {[1,2,3].map(i => <div key={i} className="skeleton" style={{ height: '72px', borderRadius: 'var(--radius)' }} />)}
        </div>
      ) : !cashBook ? (
        <div className="empty-state">
          <div className="empty-title">Initialization Error</div>
          <div className="empty-desc">Could not create cash book session.</div>
        </div>
      ) : (
        <>
          {/* Lock Banner */}
          {isLocked && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: '0.625rem',
              background: 'var(--danger-muted)', border: '1px solid var(--danger)',
              padding: '0.75rem 1rem', borderRadius: 'var(--radius)',
              color: 'var(--danger)', marginBottom: '1rem', fontSize: '0.875rem',
            }}>
              <Lock size={16} />
              <span><strong>Locked:</strong> This ledger is locked. Actions are blocked until unlocked by admin.</span>
            </div>
          )}

          {/* Balance Cards */}
          <div className="grid-2 mb-4" style={{ gap: '0.75rem' }}>
            <div className="card" style={{ padding: '0.875rem 1rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Opening Balance</span>
              <div style={{ fontSize: '1.25rem', fontWeight: 700, marginTop: '0.25rem' }}>
                ₹{cashBook.opening_balance.toLocaleString('en-IN')}
              </div>
            </div>
            <div className="card" style={{ padding: '0.875rem 1rem' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Closing Balance</span>
              <div style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--accent)', marginTop: '0.25rem' }}>
                ₹{cashBook.closing_balance.toLocaleString('en-IN')}
              </div>
            </div>
          </div>

          {/* Ledger Table */}
          <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
            <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <h3 style={{ fontSize: '0.9rem', fontWeight: 600 }}>Ledger Entries</h3>
              <div style={{ display: 'flex', gap: '0.75rem', fontSize: '0.75rem' }}>
                <span style={{ color: 'var(--success)' }}>In: ₹{totalIn.toLocaleString('en-IN')}</span>
                <span style={{ color: 'var(--danger)' }}>Out: ₹{totalOut.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {entries.length === 0 ? (
              <div className="empty-state" style={{ padding: '2rem 1rem' }}>
                <div className="empty-desc">No cash transactions logged for this day</div>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column' }}>
                {entries.map(entry => (
                  <div
                    key={entry.id}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      padding: '0.875rem 1.25rem',
                      borderBottom: '1px solid var(--border-subtle)',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span className={`cash-dot ${entry.entry_type}`} />
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{entry.category}</div>
                        {entry.note && <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '0.125rem' }}>{entry.note}</div>}
                        <div style={{ fontSize: '0.65rem', color: 'var(--text-muted)', marginTop: '0.125rem' }}>
                          {entry.created_at ? format(new Date(entry.created_at), 'hh:mm a') : ''}
                          {entry.created_by && usersMap[entry.created_by] ? ` by ${usersMap[entry.created_by]}` : ''}
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                      <span className={`cash-amount ${entry.entry_type}`} style={{ fontSize: '0.95rem', fontWeight: 700 }}>
                        {entry.entry_type === 'in' ? '+' : '-'}₹{entry.amount.toLocaleString('en-IN')}
                      </span>
                      {!isLocked && (
                        <button
                          className="btn btn-danger btn-icon btn-sm"
                          onClick={() => setConfirmDeleteId(entry.id)}
                          title="Delete entry"
                        >
                          <X size={12} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {/* Load More Button */}
                {hasMore && (
                  <div style={{ display: 'flex', justifyContent: 'center', padding: '1rem', borderTop: '1px solid var(--border-subtle)' }}>
                    <button 
                      className="btn btn-secondary" 
                      onClick={() => loadCashBook(true)}
                      disabled={loadingMore}
                      style={{ minWidth: '150px' }}
                    >
                      {loadingMore ? <span className="spinner" /> : 'Load More Entries'}
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </>
      )}

      {cashBook && !isLocked && (
        <button className="btn-fab" onClick={() => setShowForm(true)} title="Add Cash Entry">
          <Plus size={24} />
        </button>
      )}

      {/* BottomSheet Form */}
      <BottomSheet isOpen={showForm} onClose={() => setShowForm(false)} title="Add Cash Entry">
        <form onSubmit={handleSubmit}>
          {/* Type Selector */}
          <div className="form-group">
            <label className="form-label">Transaction Type</label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <button
                type="button"
                className={`btn w-full ${form.entry_type === 'out' ? 'btn-danger' : 'btn-secondary'}`}
                onClick={() => handleEntryTypeChange('out')}
              >
                Cash Out (Expense)
              </button>
              <button
                type="button"
                className={`btn w-full ${form.entry_type === 'in' ? 'btn-primary' : 'btn-secondary'}`}
                onClick={() => handleEntryTypeChange('in')}
              >
                Cash In (Deposit)
              </button>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Category</label>
            <select
              className="form-input form-select"
              value={form.category}
              onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
            >
              {form.entry_type === 'in'
                ? ENTRY_CATEGORIES_IN.map(c => <option key={c} value={c}>{c}</option>)
                : ENTRY_CATEGORIES_OUT.map(c => <option key={c} value={c}>{c}</option>)
              }
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Amount (₹) *</label>
            <input
              type="number"
              className="form-input"
              placeholder="0.00"
              value={form.amount}
              onChange={e => setForm(f => ({ ...f, amount: e.target.value }))}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Notes</label>
            <textarea
              className="form-input"
              rows={2}
              placeholder="e.g. Voucher no, description..."
              value={form.note}
              onChange={e => setForm(f => ({ ...f, note: e.target.value }))}
            />
          </div>

          {/* Receipt capture */}
          <div className="form-group">
            <label className="form-label">Receipt Image Evidence (optional)</label>
            <div style={{ display: 'flex', gap: '0.625rem' }}>
              <label style={{
                flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                gap: '0.5rem', padding: '0.75rem',
                background: 'var(--bg-elevated)', border: '1.5px dashed var(--border)',
                borderRadius: 'var(--radius)', cursor: 'pointer', fontSize: '0.875rem',
                color: 'var(--text-muted)', transition: 'all 0.15s',
              }}>
                <Camera size={18} /> Capture
                <input type="file" accept="image/*" capture="environment" style={{ display: 'none' }}
                  onChange={e => {
                    const f = e.target.files?.[0]
                    if (f) handlePhotoSelect(f)
                  }} />
              </label>
              <label style={{
                flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
                gap: '0.5rem', padding: '0.75rem',
                background: 'var(--bg-elevated)', border: '1.5px dashed var(--border)',
                borderRadius: 'var(--radius)', cursor: 'pointer', fontSize: '0.875rem',
                color: 'var(--text-muted)', transition: 'all 0.15s',
              }}>
                <ImageIcon size={18} /> Gallery
                <input type="file" accept="image/*" style={{ display: 'none' }}
                  onChange={e => {
                    const f = e.target.files?.[0]
                    if (f) handlePhotoSelect(f)
                  }} />
              </label>
            </div>
            {photoPreview && (
              <div style={{ position: 'relative', marginTop: '0.625rem' }}>
                <img src={photoPreview} alt="Preview"
                  style={{ width: '100%', maxHeight: '160px', objectFit: 'cover', borderRadius: 'var(--radius)', border: '1px solid var(--border)' }} />
                <button type="button" onClick={() => { setPhotoFile(null); setPhotoPreview(null) }}
                  style={{ position: 'absolute', top: '0.5rem', right: '0.5rem', background: 'rgba(0,0,0,0.7)', border: 'none', borderRadius: '50%', width: '28px', height: '28px', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#fff' }}>
                  <X size={14} />
                </button>
              </div>
            )}
          </div>

          <div style={{ display: 'flex', gap: '0.75rem', paddingTop: '0.5rem' }}>
            <button type="button" className="btn btn-secondary w-full" onClick={() => setShowForm(false)}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary w-full" disabled={submitting}>
              {submitting ? <span className="spinner" /> : '+ Save Entry'}
            </button>
          </div>
        </form>
      </BottomSheet>

      {/* Confirm deletion modal */}
      <ConfirmDialog 
        isOpen={confirmDeleteId !== null}
        title="Delete Cash Entry"
        message="Are you sure you want to remove this cash transaction? This will automatically update the closing balance."
        onConfirm={executeDeleteEntry}
        onCancel={() => setConfirmDeleteId(null)}
      />

      {/* Confirm Lock Book modal */}
      {cashBook && (
        <ConfirmDialog 
          isOpen={confirmLock}
          title={isLocked ? 'Unlock Ledger' : 'Lock Ledger'}
          message={isLocked
            ? 'Are you sure you want to unlock this day\'s cash book? Modifying locked balances requires extreme caution.'
            : 'Are you sure you want to lock today\'s cash book? Locked ledgers prevent further changes and are ready for admin review.'
          }
          onConfirm={executeToggleLock}
          onCancel={() => setConfirmLock(false)}
        />
      )}
    </div>
  )
}
